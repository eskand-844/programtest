import random

user_choice = int(input("what do you choose?. Type 0 for rock , Type 1 for paper, Type 2 for scissors\n"))
if user_choice == 0:
    print("You choose rock")
    print("""
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
""")

elif user_choice == 1:
    print("You choose paper")
    print("""
         _______
    ---'    ____)____
               ______)
              _______)
             _______)
    ---.__________)
    """)
elif user_choice == 2:
    print("You choose scissor")
    print("""
        _______
    ---'   ____)____
              ______)
           __________)
          (____)
    ---.__(___)
    """)

computer_choice = random.randint(0,2)
#print(f"computer choose {computer_choice}")
if user_choice >= 3 or computer_choice < 0:
    print("invalid, you lose!")
    exit()

elif computer_choice == 0:
    print("computer choose rock")
    print(("""
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
"""))
elif computer_choice == 1:
    print("computer choose paper")
    print("""
            _______
       ---'    ____)____
                  ______)
                 _______)
                _______)
       ---.__________)
       """)
elif computer_choice == 2:
    print("computer choose scissor")
    print("""
        _______
    ---'   ____)____
              ______)
           __________)
          (____)
    ---.__(___)
    """)

loose = "You Loose"
win = "You Win"

#if user_choice >= 3 or computer_choice < 0:
  #  print("invalid, you lose!")

if user_choice == 0 and computer_choice == 2:
    print(win)

elif user_choice == 2 and computer_choice == 0:
    print(loose)

elif user_choice > computer_choice:
    print(win)

elif computer_choice > user_choice:
    print(loose)

elif user_choice == computer_choice:
    print("Game draw, continue the game")


